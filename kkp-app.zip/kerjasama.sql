-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Feb 2023 pada 03.33
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kerjasama`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `keys`
--

CREATE TABLE `keys` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `key` varchar(40) NOT NULL,
  `level` int(2) NOT NULL,
  `ignore_limits` tinyint(1) NOT NULL DEFAULT 0,
  `is_private_key` tinyint(1) NOT NULL DEFAULT 0,
  `ip_addresses` text DEFAULT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `keys`
--

INSERT INTO `keys` (`id`, `user_id`, `key`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`) VALUES
(1, 1, 'sandi', 1, 0, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_proposal`
--

CREATE TABLE `tb_proposal` (
  `id` int(11) NOT NULL,
  `email` varchar(125) NOT NULL,
  `nama_media` varchar(255) NOT NULL,
  `kabiro` varchar(255) NOT NULL,
  `pimred` varchar(255) NOT NULL,
  `nama_perusahaan` varchar(255) NOT NULL,
  `alamat` varchar(520) NOT NULL,
  `npwp` varchar(255) NOT NULL,
  `no_rek` varchar(255) NOT NULL,
  `no_siup` varchar(255) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `tgl_pengajuan` int(20) NOT NULL,
  `status` varchar(25) NOT NULL,
  `verifikator` varchar(50) NOT NULL,
  `tgl_diverifikasi` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_proposal`
--

INSERT INTO `tb_proposal` (`id`, `email`, `nama_media`, `kabiro`, `pimred`, `nama_perusahaan`, `alamat`, `npwp`, `no_rek`, `no_siup`, `keterangan`, `file`, `tgl_pengajuan`, `status`, `verifikator`, `tgl_diverifikasi`) VALUES
(45, 'dila21p@gmail.com', 'GLOBAL POST', 'MISRUL HELMI', 'MINI HOLIK', 'PT. GLOBAL PRESS', 'JL.Perintis kemerdekaan 38  Rt 008/001 kel. Pulo gadung kec. Pulo gadung Jakarta timur 13260 HP.089503064468', '31.195.799.7-003.000', 'BANK MANDIRI: 1250085588556', '09.04.1.46.406825', 'Media Cetak', 'sikam_jejama1.docx', 1675654775, 'Disetujui', 'arafik1p@gmail.com', 1675675459),
(46, 'dila21p@gmail.com', 'INDOTIMES', 'HERISON', 'TAJUDDIN RASUL', 'PT. INDO TIMES MEDIA GROUP', 'JL. Alamsyah RPN Kelurahan kelapa tujuh kec.Kota bumi selatan Kab.lampung utara HP.082282610041', '43.944.851.5-326.000', 'BANK RAKYAT INDONESIA: 229393882', '2210210012588', 'Media Online', 'Contoh_2_Laporan_Komplite1.docx', 1675655402, 'Sedang diverifikasi', 'arafik1p@gmail.com', 1675675454),
(47, 'dila21p@gmail.com', 'beritanasional.co', 'FAUZI', 'HUSIN MUCHTAR', 'PT. MEDIA GEMA SEJAHTERA', 'JL. Raya Punggur no.03 lingkungan IV Srimulyo Kec.Gunung sugih LamTeng HP.082375305858', '84.859.753.0-321.000', 'BANK LAMPUNG: 385.00.02.00814.7', '\'2712210006569', 'Media Cetak', 'Contoh_1_Laporan_Komplite.pdf', 1675655524, 'Menunggu', '', 1675742455),
(48, 'riki210ap@gmail.com', 'Rinda', 'Rinda', 'Rinda', 'Rinda', 'Jl Raden intan Gadingrejo', '3992002200', 'BANK NEGARA INDONESIA: 0003994883993', '030040309', 'Media Cetak', 'Contoh_1_Laporan_Komplite_(6).pdf', 1675751667, 'Disetujui', 'arafik1p@gmail.com', 1675752294),
(49, 'riki210ap@gmail.com', 'Wati', 'wati', 'wati', 'pt wati', 'jl raya raden intan', '900299002', 'BANK CENTRAL ASIA: 929930020', '3983920020', 'Media Online', 'Contoh_1_Laporan_Komplite_(10)1.pdf', 1675751820, 'Menunggu', '', 0),
(50, 'dila21p@gmail.com', 'tika', 'tika', 'tika', 'tika', 'jl kakkaaol', '99399338888', 'BANK CENTRAL ASIA: ooiooo', '03099939', 'Media Cetak', 'Contoh_1_Laporan_Komplite_(6)1.pdf', 1675752835, 'Menunggu', '', 0),
(51, 'dila21p@gmail.com', 'sss', 'ssss', 'sss', 'sss', 'sss', 'ssss', 'BANK RAKYAT INDONESIA: sss', 'ssss', 'Media Cetak', 'Contoh_2_Laporan_Komplite.pdf', 1675827597, 'Menunggu', '', 0),
(52, 'dila21p@gmail.com', 'aaaa', 'aaaa', 'aaa', 'aaa', 'aaaa', '111', 'BANK CENTRAL ASIA: 1111', 'aaaa', 'Media Cetak', '693-1601-1-PB.pdf', 1675828022, 'Menunggu', '', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tokens`
--

CREATE TABLE `tokens` (
  `id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `user_id` int(10) NOT NULL,
  `created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `image` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(1) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `nama`, `email`, `image`, `password`, `role_id`, `is_active`, `date_created`) VALUES
(15, 'Sahrul', 'sandi@gmail.com', 'default1.jpg', '$2y$10$rcJRkHfB.NVassPUsJ6Gmu7NqmJziHeIQjlGjqbSLEqi2QCHBT4T2', 1, 1, 1674188427),
(16, 'sandi', 'sandi2@gmail.com', 'default.jpg', '$2y$10$CrwWDHhkuaKjnHuZCs/DXu02H5ztWuin8oxxTTXRC8kDAAj/05wre', 2, 1, 1674189646),
(26, 'Dila Anggita', 'dila21p@gmail.com', 'user3.jpg', '$2y$10$aVpJ09TD9cwXO1k1xxT6y.L9mTJNXwxLE5xYcPLj85iHexpLMR1jK', 2, 1, 1674279758),
(27, 'ARAFIK', 'arafik1p@gmail.com', 'myprofile.png', '$2y$10$VpsLdrzwwmCNHs9XFaxZnuingdNJ5j.PvdO4Pf6sBM4qk8An4vrU2', 3, 1, 1674811534),
(35, 'Riki', 'riki210ap@gmail.com', 'default.jpg', '$2y$10$LMjUBymYnl7.w3HoquWyG.usOEuhW/ymR4gS4UMSijxeQNsyKChrO', 2, 1, 1675352048);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `role` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user_role`
--

INSERT INTO `user_role` (`id`, `role`) VALUES
(1, 'Administrator'),
(2, 'Member'),
(3, 'verifikator');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_token`
--

CREATE TABLE `user_token` (
  `id` int(11) NOT NULL,
  `email` varchar(128) NOT NULL,
  `token` varchar(128) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user_token`
--

INSERT INTO `user_token` (`id`, `email`, `token`, `date_created`) VALUES
(9, 'dila21p@gmail.com', 'dz9pqLkFKRJKQrBIidf4vizfxhsqXno2aulIQtGZbtI=', 1674306130),
(10, 'dila21p@gmail.com', 'cdvNhYTrRuZOoMHQLG1sgvOxAqnc9xo2/nTxc7q3Qgk=', 1674306296),
(11, 'dila21p@gmail.com', 'vtD4LI0iLgBjEKMowCslXRrjpXrihh77v79bq5rg18Y=', 1674306509),
(12, 'dila21p@gmail.com', 'QfU8G0EeQ9k/UhpsZgmJ9+OfUprFumtBgp8D8Axdh3g=', 1674306676),
(13, 'dila21p@gmail.com', 'lLphYcejP+MGaKLWP4y64iAJHh8rw74c/I2EPc7E9OM=', 1674315230),
(14, 'dila21p@gmail.com', 'eKiPF4/zZnUUn41jiXqlKKJRpiEKyeA8FOdy5xvfYPg=', 1674315235),
(16, 'arafik1p@gmail.com', 'nPRdjB9Rcs1MxuFvHyl+CWjIPp2v3sNoYkJAU6nczoE=', 1674827786),
(17, 'arafik1p@gmail.com', 'pthfopa43VIzPl/hNVX30ohD5lGcuD8w3GyZgTIjc50=', 1674827790),
(18, 'arafik1p@gmail.com', 'ZhUJ7UGb/OQRUwGYacQCK2ey0+XCBtR6067lokxukL0=', 1674827901),
(19, 'arafik1p@gmail.com', 'u2IyDdXLPc9Q4MbyLE9rgSbK7xDIiQzabtewpi7qCLk=', 1674960644),
(20, 'arafik1p@gmail.com', 'QfGrhLz2wx7aaoNT2nvPGqmdORoNfy6CuSz3gui/bs0=', 1675002133),
(21, 'dila21p@gmail.com', 'FPnG+FcWs6g3GqXTOJmofLTCwPmh/OrwsZaoudlLRj4=', 1675002453),
(22, 'Khususkuliah1p@gmail.com', 'X6iqj4ww1CPR0bFFCl1fi9lwY+TqVSOK7EP50zYGNeI=', 1675317982),
(23, 'khususksuliah1p@gmail.com', 'sj5zJobUcWNB0JXwyRTgJ5aDb2Z75vY6A11JkD0Su0Y=', 1675318382),
(24, 'sandi1@gmail.com', 'l4IkjK1e6V91E2qZOozDyn6y+3EBdn96nIRa1g6cjlU=', 1675343809),
(25, 'sandi24@gmail.com', 'dwVtakKZ2B/lXgGJ+25mC6xbchJDQYbMejewC3o1l3s=', 1675344067),
(26, 'arafik1p@gmail.com', 'F4JGJr1N6+hu/iH1WIsxvof67DYbEOj2rFzhnoUF22o=', 1675347756),
(27, 'dila21p@gmail.com', '+qx59TSQqlyKt44P73awR5vPbkfTYUT8yryEGxwtTCw=', 1675350374),
(28, 'arafik1p@gmail.com', '7My/X/y/gAnWvosTs144awstD3zZRJiP7v8pIUD9q4s=', 1675351135),
(29, 'dila21p@gmail.com', 'xqsCHls4J3lPnw96YeyRzgOKqi7GG6MGZkYHjaoh9WM=', 1675351170),
(32, 'dila21p@gmail.com', 'dIUR6utTKlTCPQ/FxYtSsvri0xlixC9NRZmV/jZmW44=', 1675351549),
(33, 'sandi5@gmail.com', 'Yb931KMKkzEEYcWfEDgKkH5l7yIVB7ng5fLcYxT6JSQ=', 1675351582),
(34, 'sandi@gmail.com', 'QzF+NDanYaK9f1jHDC6mXRxxU28tSfmRB8QMbkKk1KQ=', 1675351653),
(35, 'sandi@gmail.com', '1SgEjKCqaE3nobvimjWboXu+W5rjfdrLCVQ6M8Yiuck=', 1675351793),
(36, 'sandi@gmail.com', 'QqDj8VmHVjOBS1NWe4NcXLij4OPk3mbU/lTNe7p0o+Y=', 1675351860),
(38, 'riki210ap@gmail.com', 'swi6icAspxlP89OFvEKHin6RRcGGT45MZaIkuoPmrO4=', 1675352220);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `keys`
--
ALTER TABLE `keys`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_proposal`
--
ALTER TABLE `tb_proposal`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tokens`
--
ALTER TABLE `tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indeks untuk tabel `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_token`
--
ALTER TABLE `user_token`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `keys`
--
ALTER TABLE `keys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tb_proposal`
--
ALTER TABLE `tb_proposal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT untuk tabel `tokens`
--
ALTER TABLE `tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT untuk tabel `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `user_token`
--
ALTER TABLE `user_token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `user_role` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
